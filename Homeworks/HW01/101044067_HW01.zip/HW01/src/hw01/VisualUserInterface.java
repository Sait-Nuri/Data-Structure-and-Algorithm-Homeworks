package hw01;

/**
 * @author said
 * @version 1.0
 * @created 21-Feb-2014 12:01:19 AM
 */
public interface VisualUserInterface {

	/**
	 * 
	 * @param visual
	 */
	public void command();

}
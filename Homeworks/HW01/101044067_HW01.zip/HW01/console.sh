#!/bin/bash
xterm -e "cd build/classes && java hw01.VisualConsole "

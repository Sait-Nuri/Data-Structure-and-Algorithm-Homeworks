/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hw01;

import java.awt.Graphics;
import java.awt.Graphics2D;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author said
 */
public class CanvasTest {
    
    public CanvasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of paintComponent method, of class Canvas.
     */
    @Test
    public void testPaintComponent() {
        //System.out.println("paintComponent");
        //Graphics g = null;
        //Canvas instance = null;
        //instance.paintComponent(g);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of draw_functions method, of class Canvas.
     */
    @Test
    public void testDraw_functions() {
        //System.out.println("draw_functions");
        //Graphics2D g2d = null;
        //Canvas instance = null;
        //instance.draw_functions(g2d);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}

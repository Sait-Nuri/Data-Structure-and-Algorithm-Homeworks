/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hw01;

import java.awt.Color;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author said
 */
public class VisualDataTest {
    
    public VisualDataTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getColor method, of class VisualData.
     */
    @Test
    public void testGetColor() {
        System.out.println("getColor");
        VisualData instance = null;
        Color expResult = null;
        Color result = instance.getColor();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setColor method, of class VisualData.
     */
    @Test
    public void testSetColor() {
        System.out.println("setColor");
        Color color = null;
        VisualData instance = null;
        instance.setColor(color);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFunction method, of class VisualData.
     */
    @Test
    public void testGetFunction() {
//        System.out.println("getFunction");
//        VisualData instance = new VisualData(null);
//        instance.setFunction("sin(x)");
//        String expResult = "sin(x)";
//        String result = instance.getFunction();
//        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of setFunction method, of class VisualData.
     */
    @Test
    public void testSetFunction() {
//        System.out.println("setFunction");
//        String function = "sin(x)";
//        VisualData instance = new VisualData(null);
//        instance.setFunction(function);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getRanges method, of class VisualData.
     */
    @Test
    public void testGetRanges() {
//        System.out.println("getRanges");
//        VisualData instance = null;
//        double[] expResult = null;
//        double[] result = instance.getRanges();
//        assertArrayEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of setRanges method, of class VisualData.
     */
    @Test
    public void testSetRanges() {
//        System.out.println("setRanges");
//        double[] ranges = null;
//        VisualData instance = null;
//        instance.setRanges(ranges);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of getParts method, of class VisualData.
     */
    @Test
    public void testGetParts() {
//        System.out.println("getParts");
//        VisualData instance = null;
//        String[] expResult = null;
//        String[] result = instance.getParts();
//        assertArrayEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of setParts method, of class VisualData.
     */
    @Test
    public void testSetParts() {
//        System.out.println("setParts");
//        String[] parts = null;
//        VisualData instance = null;
//        instance.setParts(parts);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
    
}

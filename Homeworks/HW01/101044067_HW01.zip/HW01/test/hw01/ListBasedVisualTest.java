/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package hw01;

import java.awt.Color;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author said
 */
public class ListBasedVisualTest {
    
    public ListBasedVisualTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of finalize method, of class ListBasedVisual.
     * @throws java.lang.Exception
     */
    @Test
    public void testFinalize() throws Exception {
//        System.out.println("finalize");
//        ListBasedVisual instance = new ListBasedVisual();
//        instance.finalize();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of addNewVisualData method, of class ListBasedVisual.
     */
    @Test
    public void testAddNewVisualData() {
//        System.out.println("addNewVisualData");
//        VisualData vd = null;
//        ListBasedVisual instance = new ListBasedVisual();
//        instance.addNewVisualData(vd);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of loadData method, of class ListBasedVisual.
     */
    @Test
    public void testLoadData() {
//        System.out.println("loadData");
//        ListBasedVisual instance = new ListBasedVisual();
//        instance.loadData();
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of parser method, of class ListBasedVisual.
     */
    @Test
    public void testParser() {
//        System.out.println("parser");
//        String line = "";
//        ListBasedVisual instance = new ListBasedVisual();
//        ParsedFormat expResult = null;
//        ParsedFormat result = instance.parser(line);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of parseFunc method, of class ListBasedVisual.
     */
    @Test
    public void testParseFunc() {
//        System.out.println("parseFunc");
//        String str1 = "";
//        ListBasedVisual instance = new ListBasedVisual();
//        String expResult = "";
//        String result = instance.parseFunc(str1);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of parseColor method, of class ListBasedVisual.
     */
    @Test
    public void testParseColor() {
//        System.out.println("parseColor");
//        String str = "";
//        ListBasedVisual instance = new ListBasedVisual();
//        Color expResult = null;
//        Color result = instance.parseColor(str);
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of parseRange method, of class ListBasedVisual.
     */
    @Test
    public void testParseRange() {
//        System.out.println("parseRange");
//        String str1 = "";
//        String str2 = "";
//        ListBasedVisual instance = new ListBasedVisual();
//        double[] expResult = null;
//        double[] result = instance.parseRange(str1, str2);
//        assertArrayEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }

    /**
     * Test of getData method, of class ListBasedVisual.
     */
    @Test
    public void testGetData() {
//        System.out.println("getData");
//        ListBasedVisual instance = new ListBasedVisual();
//        VisualData[] expResult = null;
//        VisualData[] result = instance.getData();
//        assertArrayEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }
    
}

#!/bin/bash
cd build/classes && java hw01.VisualGUI
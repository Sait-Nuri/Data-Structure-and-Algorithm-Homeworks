1-)
	Programın okuması gerektiği dosya HW01/file.txt
	Consoldan çalışan programın okuması gerektiği dosya /HW01/build/classes
	JUNIT'in okuması gerektiği /HW01/test

2-)
	Program bash script çalıştırıyor. HW01 klasörünün içerisindeki gui.sh ve console.sh dosyasının executable olması gerekiyor.
	
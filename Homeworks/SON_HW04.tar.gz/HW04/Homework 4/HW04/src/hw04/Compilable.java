package hw04;

/**
 * @author said
 * @version 1.0
 * @created 31-Mar-2014 10:09:38 PM
 */
public interface Compilable {

	public void compileAndRun();

}